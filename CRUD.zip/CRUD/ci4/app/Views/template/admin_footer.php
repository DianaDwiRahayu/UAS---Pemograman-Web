        </section>
    </section>
    <footer>
        <p>&copy; by Diana Dwi R. - 312010055</p>
    </footer>
    </div>
</body>
</html>